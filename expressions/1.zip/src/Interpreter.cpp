#include "pch.h"
#include "Interpreter.hpp"

#include "Literal.hpp"


//**************************************************************** */

Printer::Printer()
{
    text = "";
}

std::unique_ptr<Expr> Printer::visit(std::unique_ptr<Expr> expr)
{
    return expr->accept(this);
}

void Printer::printOP(TokenType type)
{
    std::string op = "";

    if (type == TokenType::PLUS)
    {
        op = "+";
    }
    else if (type == TokenType::MINUS)
    {
        op = "-";
    }
    else if (type == TokenType::SLASH)
    {
        op = "/";
    }
    else if (type == TokenType::MOD)
    {
        op = "%";
    }
    else if (type == TokenType::STAR)
    {
        op = "*";
    }
    else if (type == TokenType::POWER)
    {
        op = "^";
    }
    else if (type == TokenType::GREATER)
    {
        op = ">";
    }
    else if (type == TokenType::GREATER_EQUAL)
    {
        op = ">=";
    }
    else if (type == TokenType::LESS)
    {
        op = "<";
    }
    else if (type == TokenType::LESS_EQUAL)
    {
        op = "<=";
    }
    else if (type == TokenType::BANG_EQUAL)
    {
        op = "!=";
    }
    else if (type == TokenType::EQUAL_EQUAL)
    {
        op = "==";
    }

    text += op;
}

std::unique_ptr<Expr> Printer::visitBinaryExpr(BinaryExpr *expr)
{
    std::unique_ptr<Expr> left  = std::move(expr->left);
    std::unique_ptr<Expr> right = std::move(expr->right);
    text += "Binary: (";


    if (left->getType() ==ExprType::LITERAL && right->getType() == ExprType::LITERAL)
    {
        LiteralExpr *leftVal = dynamic_cast<LiteralExpr*>(left.get());
        LiteralExpr *rightVal = dynamic_cast<LiteralExpr*>(right.get());

       
        visitLiteralExpr(leftVal);
        text += " ";
        printOP(expr->op.type);
        text += " ";
        visitLiteralExpr(rightVal);
        text += ")";
    } else if (left->getType() == ExprType::BINARY)
    {
        BinaryExpr *leftVal = dynamic_cast<BinaryExpr*>(left.get());

        visitBinaryExpr(leftVal);
        text += " ";
        printOP(expr->op.type);
        text += ")";
    }
    else if (right->getType() == ExprType::GROUPING)
    {

        GroupingExpr *rightVal = dynamic_cast<GroupingExpr*>(right.get());
        text += " ";
        printOP(expr->op.type);
        text += " ";
        visitGroupingExpr(rightVal);
        text += ")";

    } else if (left->getType() == ExprType::GROUPING)
    {
        GroupingExpr *leftVal = dynamic_cast<GroupingExpr*>(left.get());
        text += " ";
        printOP(expr->op.type);
        text += " ";
        visitGroupingExpr(leftVal);
        text += ")";
    } else if (right->getType() == ExprType::BINARY)
    {
        BinaryExpr *rightVal = dynamic_cast<BinaryExpr*>(right.get());
        text += " ";
        printOP(expr->op.type);
        text += " ";
        visitBinaryExpr(rightVal);
        text += ")";
    } else 
    {
        text += "Unknown";
        text += ")";
    }

    return nullptr;
}

std::unique_ptr<Expr> Printer::visitLogicalExpr(LogicalExpr *expr)
{
    text += "Logical: (";
    expr->left->accept(this);
    text += " ";
    printOP(expr->op.type);
    text += " ";
    expr->right->accept(this);
    text += ")";

    return nullptr;
}

std::unique_ptr<Expr> Printer::visitGroupingExpr(GroupingExpr *expr)
{
    text += "Group: (";
    expr->expression->accept(this);
    text += ")";
    return nullptr;
}


std::unique_ptr<Expr> Printer::visitLiteralExpr(LiteralExpr *expr)
{
    text += "Literal: (";
    text += expr->value->toString();
    text += ")";
    return nullptr;
}


std::unique_ptr<Expr> Printer::visitUnaryExpr(UnaryExpr *expr)
{
     text += "Unary: (";
    std::unique_ptr<Expr> right = std::move(expr->right);
    if (right->getType() == ExprType::LITERAL)
    {
        LiteralExpr *rightVal = dynamic_cast<LiteralExpr*>(right.get());
       
        printOP(expr->op.type);
        text += " ";
        visitLiteralExpr(rightVal);
        text += ")\n";
    }
    
    return nullptr;
}







void Printer::print(std::unique_ptr<Expr> expr)
{
    visit(std::move(expr));
    std::cout << "Start(" << std::endl;
    std::cout << text << std::endl;
    std::cout << ")End" << std::endl;
}


/***************************************************************************************** */
std::unique_ptr<Expr> Interpreter::visit(std::unique_ptr<Expr> expr)
{
    return expr->accept(this);
}


std::unique_ptr<Expr> Interpreter::visitBinaryExpr(BinaryExpr *expr)
{
     std::unique_ptr<Expr> left  = std::move(expr->left);
     std::unique_ptr<Expr> right = std::move(expr->right);

     Token op = expr->op;
    
         if (left->getType() == ExprType::LITERAL && right->getType() == ExprType::LITERAL)
         {
             LiteralExpr *leftVal = dynamic_cast<LiteralExpr*>(left.get());
             LiteralExpr *rightVal = dynamic_cast<LiteralExpr*>(right.get());
           
             if (op.type == TokenType::PLUS)
            {

                if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::INT)
                {
                    int a = leftVal->value->getIntValue();
                    int b = rightVal->value->getIntValue();
                    return createIntLiteral(a + b);
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    float a = leftVal->value->getFloatValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(a + b);
                } else if (leftVal->value->getType() == LiteralType::STRING && rightVal->value->getType() == LiteralType::STRING)
                {
                    std::string a = leftVal->value->getStringValue();
                    std::string b = rightVal->value->getStringValue();
                    return createStringLiteral(a + b);
                } else if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    int a   = leftVal->value->getIntValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(a + b);
                }
                else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::INT)
                {
                    float a = leftVal->value->getFloatValue();
                    int b = rightVal->value->getIntValue();
                    return createFloatLiteral(a + b);
                } else if (leftVal->value->getType() == LiteralType::STRING && rightVal->value->getType() == LiteralType::INT)
                {
                    std::string a = leftVal->value->getStringValue();
                    int b = rightVal->value->getIntValue();
                    return createStringLiteral(a + std::to_string(b));
                } 
                else if (leftVal->value->getType() == LiteralType::STRING && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    std::string a = leftVal->value->getStringValue();
                    float b = rightVal->value->getFloatValue();
                    return createStringLiteral(a + std::to_string(b));
                } 
                else if (leftVal->value->getType() == LiteralType::STRING && rightVal->value->getType() == LiteralType::STRING)
                {
                    std::string a = leftVal->value->getStringValue();
                    std::string b = rightVal->value->getStringValue();
                    return createStringLiteral(a + b);
                }
                else if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::STRING)
                {
                    Error(expr->op,"Cannot add a string to an int");
                    return nullptr;
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::STRING)
                {
                    Error(expr->op,"Cannot add a string to an float");
                    return nullptr;
                } else 
                {
                    Error(expr->op," Cannot add two different types");
                    return nullptr;
                }
                
         }// +
         else if (op.type == TokenType::MINUS)
         {
                 if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::INT)
                {
                    int a = leftVal->value->getIntValue();
                    int b = rightVal->value->getIntValue();
                    return createIntLiteral(a - b);
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    float a = leftVal->value->getFloatValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(a - b);
                } else if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    int a   = leftVal->value->getIntValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(a - b);
                }
                else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::INT)
                {
                    float a = leftVal->value->getFloatValue();
                    int b = rightVal->value->getIntValue();
                    return createFloatLiteral(a - b);
                }
                else
                {
                    Error(expr->op," not a number");
                    return nullptr;
                }
                 
         }//-
         else if (op.type == TokenType::SLASH)
         {
             if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::INT)
                {
                    int a = leftVal->value->getIntValue();
                    int b = rightVal->value->getIntValue();
                    if (b == 0)
                    {
                        Error(expr->op,"Divide by zero");
                        return nullptr;
                    }
                    return createIntLiteral(a / b);
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    float a = leftVal->value->getFloatValue();
                    float b = rightVal->value->getFloatValue();
                    if (b == 0.0)
                    {
                        Error(expr->op,"Divide by zero");
                        return nullptr;
                    }
                    return createFloatLiteral(a / b);
                }
                else
                {
                    Error(expr->op," not a number or same types");
                    return nullptr;
                }

         }// div
         else if (op.type == TokenType::STAR)
         {
             if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::INT)
                {
                    int a = leftVal->value->getIntValue();
                    int b = rightVal->value->getIntValue();
                    return createIntLiteral(a * b);
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    float a = leftVal->value->getFloatValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(a * b);
                } else if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    int a   = leftVal->value->getIntValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(a * b);
                }
                else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::INT)
                {
                    float a = leftVal->value->getFloatValue();
                    int b = rightVal->value->getIntValue();
                    return createFloatLiteral(a * b);
                }
                else
                {
                    Error(expr->op," not a number");
                    return nullptr;
                }
            }//*
            else if (op.type == TokenType::MOD)
            {
                if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    Error(expr->op," cant mod float with int");
                    return nullptr;
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::INT)
                {
                    Error(expr->op," cant mod float with int");
                    return nullptr; 
                }

                if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::INT)
                {
                    int a = leftVal->value->getIntValue();
                    int b = rightVal->value->getIntValue();
                    return createIntLiteral(a % b);
                }
                else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    float a = leftVal->value->getFloatValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(std::fmod(a,b) );
                }
            } else if (op.type == TokenType::POWER)
            {
                if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::INT)
                {
                    int a = leftVal->value->getIntValue();
                    int b = rightVal->value->getIntValue();
                    return createIntLiteral(static_cast<int>(std::pow(a,b)));
                } else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    float a = leftVal->value->getFloatValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(std::pow(a,b));
                } else if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    int a   = leftVal->value->getIntValue();
                    float b = rightVal->value->getFloatValue();
                    return createFloatLiteral(std::pow(a,b));
                }
                else if (leftVal->value->getType() == LiteralType::FLOAT && rightVal->value->getType() == LiteralType::INT)
                {
                    Error(expr->op," cant mod float with int");
                    return nullptr;
                } else if (leftVal->value->getType() == LiteralType::INT && rightVal->value->getType() == LiteralType::FLOAT)
                {
                    Error(expr->op," cant mod float with int");
                    return nullptr;
                }
                else
                {
                    Error(expr->op," not a number");
                    return nullptr;
                }

            }
         else
         {
             Error(expr->op,"Unknown operator");
             return nullptr;
         }
     }//literals 
     return nullptr;    
   
}

std::unique_ptr<Expr> Interpreter::visitLogicalExpr(LogicalExpr *expr)
{
    std::unique_ptr<Expr> left  = evaluate(std::move(expr->left));
    
    Token op = expr->op;
     if (left->getType() == ExprType::LITERAL)
     {
        LiteralExpr *leftVal = dynamic_cast<LiteralExpr*>(left.get());

         if (op.type == TokenType::OR)
        {
        
            
            if (leftVal->value->getType() == LiteralType::BOOLEAN)
            {
                bool value = leftVal->value->getBoolValue();
                if (value)
                {
                    return left;
                } else
                {
                    return evaluate(std::move(expr->right));
                }
            } else if (leftVal->value->getType() == LiteralType::INT)
            {
                int value = leftVal->value->getIntValue();
                if (value)
                {
                    return left;
                } else
                {
                    return evaluate(std::move(expr->right));
                }
            } else if (leftVal->value->getType() == LiteralType::POINTER)
            {
                void* value = leftVal->value->getPointerValue();
                if (value)
                {
                    return left;
                } else
                {
                    return evaluate(std::move(expr->right));
                }
            }
            else
            {
                Error(expr->op,"not logic operator");
                return nullptr;
            }
         
        } else if (op.type == TokenType::AND)
        {
                bool value = leftVal->value->getBoolValue();
                if (value)
                {
                    return evaluate(std::move(expr->right));
                } else
                {
                    return left;
                }
            } else if (leftVal->value->getType() == LiteralType::INT)
            {
                int value = leftVal->value->getIntValue();
                if (value)
                {
                    return evaluate(std::move(expr->right));
                } else
                {
                    return left;
                }
            } else if (leftVal->value->getType() == LiteralType::POINTER)
            {
                void* value = leftVal->value->getPointerValue();
                if (value)
                {
                    return evaluate(std::move(expr->right));
                } else
                {
                    return left;
                }
            }
            else
            {
                Error(expr->op,"not logic operator");
                return nullptr;
            }
     }
    return evaluate(std::move(expr->right));
   
}

std::unique_ptr<Expr> Interpreter::visitGroupingExpr(GroupingExpr *expr)
{
    return evaluate(std::move(expr->expression));
}


std::unique_ptr<Expr> Interpreter::visitLiteralExpr(LiteralExpr *expr)
{
    if (expr->value->getType() == LiteralType::INT)
    {
        return createIntLiteral(expr->value->getIntValue());
    } else if (expr->value->getType() == LiteralType::FLOAT)
    {
        return createFloatLiteral(expr->value->getFloatValue());
    } else if (expr->value->getType() == LiteralType::BOOLEAN)
    {
        return createBoolLiteral(expr->value->getBoolValue());
    } else if (expr->value->getType() == LiteralType::STRING)
    {
        return createStringLiteral(expr->value->getStringValue());
    } else if (expr->value->getType() == LiteralType::POINTER)
    {
       
        return createPointerLiteral(expr->value->getPointerValue());
    }
    return nullptr;
   
}


std::unique_ptr<Expr> Interpreter::visitUnaryExpr(UnaryExpr *expr)
{
    std::unique_ptr<Expr> right = std::move(expr->right);
    

        if (expr->op.type== TokenType::MINUS)
        {
           if (right->getType() == ExprType::LITERAL)
           {
               LiteralExpr *rightVal = dynamic_cast<LiteralExpr*>(right.get());
               if (rightVal->value->getType() == LiteralType::FLOAT)
               {
                   float value = -rightVal->value->getFloatValue();
                   return createIntLiteral(value);
               } else if (rightVal->value->getType() == LiteralType::INT)
               {
                   int value = -rightVal->value->getIntValue();
                   return createIntLiteral(value);
               } else if (rightVal->value->getType() == LiteralType::BOOLEAN)
               {
                   bool value = !rightVal->value->getBoolValue();
                   return createBoolLiteral(value);
               }else if (rightVal->value->getType() == LiteralType::STRING)
               {
                    Error(expr->op,"Cannot negate a string");
                    return nullptr;
               } else 
               {
                    Error(expr->op,"Unknown type");
                    return nullptr;
               }
           }

         else if (expr->op.type == TokenType::NOT)
         {
                if (right->getType() == ExprType::LITERAL)
                {
                    LiteralExpr *rightVal = dynamic_cast<LiteralExpr*>(right.get());
                    if (rightVal->value->getType() == LiteralType::INT)
                    {
                        int value = !rightVal->value->getIntValue();
                        return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
                    } if (rightVal->value->getType() == LiteralType::BOOLEAN)
                    {
                        bool value = !rightVal->value->getBoolValue();
                        return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
                    }
                    else 
                    {
                        Error(expr->op,"Can negate operator only on int or bool");
                        return nullptr;
                    }
               
            }            
        }
    }

    return nullptr;
   
}

std::unique_ptr<Expr> Interpreter::evaluate(std::unique_ptr<Expr> expr)
{
    return expr->accept(this);
}

void Interpreter::interpret(std::unique_ptr<Expr> expr)
{
  std::unique_ptr<Expr> result =  evaluate(std::move(expr));
  if (result)
  {
    if (result->getType() == ExprType::LITERAL)
    {
        LiteralExpr *literal = dynamic_cast<LiteralExpr*>(result.get());
        std::cout <<"Result: ("<< literal->value->toString()<<")" << std::endl;
    }
     
  } else 
  {
    std::cout <<"Result: (null)" << std::endl;
  }
}


void Interpreter::Error(const Token &token,const std::string &message)
{
    panicMode = true;
    int line = token.line;
    std::string text ="ERROR: " +message+ " at line: " +std::to_string(line);
    throw std::runtime_error(text);
}

void Interpreter::Warning(const Token &token,const std::string &message)
{
    int line = token.line;
    std::string text ="WARNING: " +message+ " at line: " +std::to_string(line);
    throw std::runtime_error(text);
}

std::unique_ptr<LiteralExpr> Interpreter::createIntLiteral(int value)
{
    return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
}

std::unique_ptr<LiteralExpr> Interpreter::createFloatLiteral(float value)
{
    return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
}

std::unique_ptr<LiteralExpr> Interpreter::createStringLiteral(const std::string &value)
{
    return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
}

std::unique_ptr<LiteralExpr> Interpreter::createBoolLiteral(bool value)
{
   
    return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
}

std::unique_ptr<LiteralExpr> Interpreter::createPointerLiteral(void *value)
{
    return std::make_unique<LiteralExpr>(std::make_unique<Literal>(value));
}



