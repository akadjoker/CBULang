
#include "pch.h"
#include "Token.hpp"
#include "Literal.hpp"
#include "Lexer.hpp"
#include "Parser.hpp"
#include "Interpreter.hpp"



int main()
{

    std::string code = R"(
        
   
        3 *2 ^2
        
        )";


try
{

    Lexer lexer = Lexer(code);
    std::vector<Token> tokens = lexer.scanTokens();
    for (Token token : tokens)
    {
      // std::cout << token.toString() << std::endl;
    }
    Parser parser = Parser(tokens);
    std::unique_ptr<Expr> result = parser.result();

   // Printer printer;
   // printer.print(std::move(result));
   Interpreter interpreter;
   interpreter.interpret(std::move(result));
 
}
catch (const std::runtime_error& e) 
{
        std::cerr << " " << e.what() << std::endl;
        }

    return 0;
}
