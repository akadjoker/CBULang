
#include <cstring>

#include <new>
#include <utility>
#include <typeinfo>

#include <algorithm>

#include <memory>
#include <unordered_map>
#include <cmath>
#include <cctype>

#include <string>
#include <vector>
#include <iostream>
#include <fstream>

#include <stdexcept>











